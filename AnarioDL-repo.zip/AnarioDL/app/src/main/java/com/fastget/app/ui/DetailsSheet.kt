package com.fastget.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.fastget.app.core.I18n
import com.fastget.app.core.formatBytes
import com.fastget.app.core.formatEta
import com.fastget.app.core.formatSpeed
import com.fastget.app.data.DownloadEntity
import com.fastget.app.data.Status
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailsSheet(
    e: DownloadEntity,
    liveSpeed: Long,
    liveEta: Long,
    vm: MainViewModel,
    onDismiss: () -> Unit,
) {
    val prefs = vm.prefs
    var url by remember(e.id) { mutableStateOf(e.url) }
    var path by remember(e.id) { mutableStateOf(e.customPath) }
    var priority by remember(e.id) { mutableStateOf(e.priority.toString()) }
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val df = remember {
        SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault())
    }
    val speed = if (liveSpeed > 0) liveSpeed else e.avgSpeed
    val remain = when {
        liveEta > 0 -> liveEta
        speed > 0 && e.totalBytes > 0 && e.downloadedBytes < e.totalBytes ->
            ((e.totalBytes - e.downloadedBytes) / speed)
        else -> -1L
    }

    ModalBottomSheet(onDismissRequest = onDismiss, sheetState = sheet) {
        Column(
            Modifier
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
        ) {
            Text(e.fileName, style = MaterialTheme.typography.titleMedium)
            Text(
                I18n.t(prefs, "وضعیت", "Status") + ": " + e.status,
                style = MaterialTheme.typography.bodySmall,
            )
            Text(
                I18n.t(prefs, "حجم", "Size") + ": " +
                    if (e.totalBytes > 0) formatBytes(e.totalBytes) else "—",
            )
            Text(
                I18n.t(prefs, "دانلود شده", "Downloaded") + ": " + formatBytes(e.downloadedBytes),
            )
            if (speed > 0) Text(I18n.t(prefs, "سرعت", "Speed") + ": " + formatSpeed(speed))
            if (remain > 0) Text(I18n.t(prefs, "زمان باقی‌مانده", "ETA") + ": " + formatEta(remain))
            Text(
                I18n.t(prefs, "تاریخ", "Created") + ": " + df.format(Date(e.createdAt)),
            )
            if (e.finishedAt > 0) {
                Text(
                    I18n.t(prefs, "اتمام", "Finished") + ": " + df.format(Date(e.finishedAt)),
                )
            }
            if (!e.localPath.isNullOrBlank()) {
                Text(
                    I18n.t(prefs, "مسیر", "Path") + ": " + e.localPath,
                    style = MaterialTheme.typography.bodySmall,
                )
            }

            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(I18n.t(prefs, "لینک", "URL")) },
                minLines = 2,
            )
            OutlinedTextField(
                value = path,
                onValueChange = { path = it },
                modifier = Modifier.fillMaxWidth(),
                label = {
                    Text(I18n.t(prefs, "پوشه سفارشی (خالی = پیش‌فرض)", "Custom folder (empty = default)"))
                },
            )
            OutlinedTextField(
                value = priority,
                onValueChange = { priority = it.filter { ch -> ch.isDigit() || ch == '-' } },
                modifier = Modifier.fillMaxWidth(),
                label = { Text(I18n.t(prefs, "اولویت (عدد بالاتر = زودتر)", "Priority (higher first)")) },
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
                when (e.status) {
                    Status.DOWNLOADING, Status.QUEUED -> {
                        IconButton(onClick = { vm.manager.pause(e.id) }) {
                            Icon(Icons.Rounded.Pause, contentDescription = "pause")
                        }
                    }
                    else -> {
                        IconButton(onClick = { vm.manager.resume(e.id) }) {
                            Icon(Icons.Rounded.PlayArrow, contentDescription = "play")
                        }
                    }
                }
                IconButton(onClick = { vm.manager.retry(e.id) }) {
                    Icon(Icons.Rounded.Refresh, contentDescription = "retry")
                }
                Spacer(Modifier = Modifier.weight(1f))
                TextButton(onClick = onDismiss) {
                    Text(I18n.t(prefs, "بستن", "Close"))
                }
                Button(
                    onClick = {
                        if (url.trim() != e.url) vm.manager.updateUrl(e.id, url.trim())
                        if (path != e.customPath) vm.manager.setCustomPath(e.id, path.trim())
                        priority.toIntOrNull()?.let { if (it != e.priority) vm.manager.setPriority(e.id, it) }
                        onDismiss()
                    },
                ) {
                    Text(I18n.t(prefs, "ذخیره", "Save"))
                }
            }
            Spacer(Modifier = Modifier.height(24.dp))
        }
    }
}
