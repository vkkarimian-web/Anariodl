package com.fastget.app.data

import androidx.room.Entity
import androidx.room.PrimaryKey

object Status {
    const val QUEUED = "QUEUED"
    const val DOWNLOADING = "DOWNLOADING"
    const val PAUSED = "PAUSED"
    const val COMPLETED = "COMPLETED"
    const val FAILED = "FAILED"
}

object Kind {
    const val FILE = "FILE"
    /** yt-dlp engine (YouTube, Instagram, adult sites, …). */
    const val VIDEO = "VIDEO"
}

@Entity(tableName = "downloads")
data class DownloadEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    /** Page / direct URL. For VIDEO keep the page URL (not CDN) so re-extract works. */
    val url: String,
    val fileName: String,
    val category: String,
    val localPath: String = "",
    /** Optional override folder; empty = default category folder. */
    val customPath: String = "",
    val totalBytes: Long = -1,
    val downloadedBytes: Long = 0,
    val status: String = Status.QUEUED,
    val segments: String = "",
    val acceptRanges: Boolean = false,
    val etag: String? = null,
    val lastModified: String? = null,
    val error: String? = null,
    val publicUri: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val finishedAt: Long = 0,
    val kind: String = Kind.FILE,
    val formatSpec: String = "",
    val isPrivate: Boolean = false,
    val thumbnail: String? = null,
    /** Higher runs first in the queue (0 = normal). */
    val priority: Int = 0,
    /** Epoch ms; 0 = no schedule window start. */
    val scheduleStartMs: Long = 0,
    /** Epoch ms; 0 = no auto-stop (kill-switch). */
    val scheduleStopMs: Long = 0,
    /** Rolling average speed (bytes/sec) for ETA. */
    val avgSpeed: Long = 0,
)
