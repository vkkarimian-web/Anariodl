package com.fastget.app.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface DownloadDao {
    @Query("SELECT * FROM downloads ORDER BY priority DESC, createdAt DESC")
    fun observeAll(): Flow<List<DownloadEntity>>

    @Query("SELECT * FROM downloads WHERE id = :id")
    suspend fun get(id: Long): DownloadEntity?

    @Query(
        """
        SELECT * FROM downloads
        WHERE status = :status
        ORDER BY priority DESC, createdAt ASC
        """
    )
    suspend fun byStatus(status: String): List<DownloadEntity>

    @Insert
    suspend fun insert(e: DownloadEntity): Long

    @Update
    suspend fun update(e: DownloadEntity)

    @Query("UPDATE downloads SET status = :status, error = :error WHERE id = :id")
    suspend fun setStatus(id: Long, status: String, error: String?)

    @Query("UPDATE downloads SET status = :to WHERE status = :from")
    suspend fun moveStatus(from: String, to: String)

    @Query(
        """
        UPDATE downloads SET
          downloadedBytes = :downloaded,
          segments = :segments
        WHERE id = :id
        """
    )
    suspend fun setProgress(id: Long, downloaded: Long, segments: String)

    @Query(
        """
        UPDATE downloads SET
          downloadedBytes = :downloaded,
          totalBytes = :total,
          segments = :segments,
          avgSpeed = :avgSpeed
        WHERE id = :id
        """
    )
    suspend fun setProgressFull(
        id: Long,
        downloaded: Long,
        total: Long,
        segments: String,
        avgSpeed: Long,
    )

    @Query("UPDATE downloads SET url = :url WHERE id = :id")
    suspend fun setUrl(id: Long, url: String)

    @Query("UPDATE downloads SET customPath = :path WHERE id = :id")
    suspend fun setCustomPath(id: Long, path: String)

    @Query("UPDATE downloads SET priority = :priority WHERE id = :id")
    suspend fun setPriority(id: Long, priority: Int)

    @Query(
        """
        UPDATE downloads SET
          scheduleStartMs = :startMs,
          scheduleStopMs = :stopMs
        WHERE id = :id
        """
    )
    suspend fun setSchedule(id: Long, startMs: Long, stopMs: Long)

    @Query("DELETE FROM downloads WHERE id = :id")
    suspend fun delete(id: Long)
}
