package com.fastget.app.core

import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import okhttp3.Call
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.net.URLDecoder
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.file.StandardOpenOption
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

const val USER_AGENT =
    "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) " +
        "Chrome/124.0 Mobile Safari/537.36"

class ProbeResult(
    val total: Long,
    val acceptRanges: Boolean,
    val fileName: String?,
    val etag: String?,
    val lastModified: String?
)

/** One byte range [start, end] of the file. end = -1 means "unknown length". */
class Seg(val start: Long, val end: Long, done: Long = 0) {
    val done = AtomicLong(done)
    val length: Long get() = if (end < 0) -1 else end - start + 1
    val finished: Boolean get() = end >= 0 && done.get() >= length
}

object Segments {
    fun encode(list: List<Seg>): String =
        list.joinToString(";") { "${it.start}:${it.end}:${it.done.get()}" }

    fun decode(s: String): List<Seg> =
        if (s.isBlank()) emptyList()
        else s.split(";").mapNotNull {
            val p = it.split(":")
            if (p.size != 3) null
            else {
                val a = p[0].toLongOrNull()
                val b = p[1].toLongOrNull()
                val c = p[2].toLongOrNull()
                if (a == null || b == null || c == null) null else Seg(a, b, c)
            }
        }

    /** Files under 1 MB are not worth splitting. */
    fun split(total: Long, threads: Int): List<Seg> {
        val count = if (total < 1L * 1024 * 1024) 1 else threads.coerceIn(1, 32)
        val size = total / count
        return (0 until count).map { i ->
            val s = i * size
            val e = if (i == count - 1) total - 1 else s + size - 1
            Seg(s, e)
        }
    }
}

/** Simple per-download speed limiter (bytes per second, 0 = unlimited). */
class SpeedLimiter(private val bytesPerSec: Long) {
    private var windowStart = System.nanoTime()
    private var used = 0L

    @Synchronized
    fun delayFor(n: Int): Long {
        if (bytesPerSec <= 0) return 0
        val now = System.nanoTime()
        if (now - windowStart >= 1_000_000_000L) {
            windowStart = now
            used = 0
        }
        used += n
        return if (used > bytesPerSec) {
            ((1_000_000_000L - (now - windowStart)) / 1_000_000L).coerceAtLeast(0)
        } else 0
    }
}

/** One instance per download so [abort] only touches that download's connections. */
class SegmentedDownloader(private val client: OkHttpClient) {

    private val activeCalls = ConcurrentHashMap.newKeySet<Call>()

    fun abort() {
        activeCalls.forEach { it.cancel() }
    }

    /** Asks for bytes 0-0 to learn size, range support, name and validators in one request. */
    fun probe(url: String): ProbeResult {
        val req = Request.Builder().url(url)
            .header("Range", "bytes=0-0")
            .header("User-Agent", USER_AGENT)
            .build()
        val call = client.newCall(req)
        activeCalls.add(call)
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw IOException("خطای سرور: ${r.code}")
                val name = r.header("Content-Disposition")?.let { parseDispositionName(it) }
                val etag = r.header("ETag")
                val lm = r.header("Last-Modified")
                if (r.code == 206) {
                    val total = r.header("Content-Range")
                        ?.substringAfter('/', "")?.toLongOrNull() ?: -1L
                    return ProbeResult(total, total > 0, name, etag, lm)
                }
                val len = r.body?.contentLength() ?: -1L
                return ProbeResult(len, false, name, etag, lm)
            }
        } finally {
            activeCalls.remove(call)
        }
    }

    private fun parseDispositionName(header: String): String? {
        Regex("""filename\*\s*=\s*[^']*''([^;]+)""", RegexOption.IGNORE_CASE)
            .find(header)?.let {
                return runCatching { URLDecoder.decode(it.groupValues[1].trim(), "UTF-8") }.getOrNull()
            }
        Regex("""filename\s*=\s*"?([^";]+)"?""", RegexOption.IGNORE_CASE)
            .find(header)?.let { return it.groupValues[1].trim() }
        return null
    }

    /**
     * Downloads all unfinished segments in parallel into [partFile].
     * [onTick] is called twice per second with (downloadedBytes, bytesPerSec, encodedSegments).
     */
    suspend fun download(
        url: String,
        partFile: File,
        total: Long,
        useRange: Boolean,
        segs: List<Seg>,
        limiter: SpeedLimiter,
        onTick: suspend (downloaded: Long, speed: Long, segments: String) -> Unit
    ) = coroutineScope {
        partFile.parentFile?.mkdirs()
        val ch = FileChannel.open(
            partFile.toPath(),
            StandardOpenOption.CREATE, StandardOpenOption.WRITE, StandardOpenOption.READ
        )
        if (total > 0 && ch.size() < total) {
            ch.write(ByteBuffer.wrap(byteArrayOf(0)), total - 1)
        }

        val ticker = launch {
            var last = segs.sumOf { it.done.get() }
            var lastT = System.nanoTime()
            var smooth = 0.0
            while (isActive) {
                delay(500)
                val now = System.nanoTime()
                val cur = segs.sumOf { it.done.get() }
                val inst = (cur - last) * 1e9 / (now - lastT).coerceAtLeast(1)
                smooth = if (smooth == 0.0) inst else smooth * 0.6 + inst * 0.4
                last = cur
                lastT = now
                onTick(cur, smooth.toLong(), Segments.encode(segs))
            }
        }

        try {
            segs.filter { !it.finished }
                .map { seg ->
                    async(Dispatchers.IO) { runSegment(url, seg, ch, limiter, useRange) }
                }
                .awaitAll()
        } finally {
            ticker.cancel()
            runCatching { ch.close() }
        }
    }

    private suspend fun runSegment(
        url: String,
        seg: Seg,
        ch: FileChannel,
        limiter: SpeedLimiter,
        useRange: Boolean
    ) {
        val buf = ByteArray(64 * 1024)
        var attempt = 0
        while (true) {
            currentCoroutineContext().ensureActive()
            val from = seg.start + seg.done.get()
            if (seg.end >= 0 && from > seg.end) return
            try {
                val rb = Request.Builder().url(url).header("User-Agent", USER_AGENT)
                if (useRange) rb.header("Range", "bytes=$from-${if (seg.end >= 0) seg.end else ""}")
                val call = client.newCall(rb.build())
                activeCalls.add(call)
                try {
                    call.execute().use { r ->
                        if (useRange && r.code != 206) {
                            throw IOException("سرور درخواست بازه‌ای را نپذیرفت (${r.code})")
                        }
                        if (!r.isSuccessful) throw IOException("خطای سرور: ${r.code}")
                        val input = (r.body ?: throw IOException("پاسخ خالی از سرور")).byteStream()
                        var pos = from
                        while (true) {
                            val n = input.read(buf)
                            if (n < 0) break
                            val bb = ByteBuffer.wrap(buf, 0, n)
                            while (bb.hasRemaining()) pos += ch.write(bb, pos)
                            seg.done.addAndGet(n.toLong())
                            val d = limiter.delayFor(n)
                            if (d > 0) delay(d) else currentCoroutineContext().ensureActive()
                        }
                    }
                } finally {
                    activeCalls.remove(call)
                }
                if (seg.end < 0 || seg.finished) return
                throw IOException("اتصال پیش از پایان دانلود قطع شد")
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                currentCoroutineContext().ensureActive()
                // Without Range support a retry must restart from byte 0.
                if (!useRange) seg.done.set(0)
                if (++attempt > 6) throw e
                delay(800L * attempt)
            }
        }
    }
}
