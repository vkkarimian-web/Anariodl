package com.fastget.app.core

/** Tiny runtime strings. UI uses this so language switch works without activity recreate. */
object I18n {
    fun t(prefs: Prefs, fa: String, en: String): String =
        if (prefs.language == "en") en else fa

    fun appTitle(prefs: Prefs): String =
        if (prefs.language == "en") "Anario DL" else "آناریو"
}
