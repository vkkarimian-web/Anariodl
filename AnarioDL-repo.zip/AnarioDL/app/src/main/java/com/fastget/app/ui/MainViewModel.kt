package com.fastget.app.ui

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.fastget.app.FastGetApp
import com.fastget.app.core.SearchItem
import com.fastget.app.core.SearchSource
import com.fastget.app.core.Security
import com.fastget.app.core.VideoEngine
import com.fastget.app.core.VideoMeta
import com.fastget.app.data.DownloadEntity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn

enum class Screen { HOME, SETTINGS, VIDEO, VAULT }

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val fg = app as FastGetApp

    val manager get() = fg.manager
    val prefs get() = fg.prefs

    val downloads: StateFlow<List<DownloadEntity>> =
        fg.db.dao().observeAll()
            .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    val live get() = fg.manager.live

    var screen by mutableStateOf(Screen.HOME)
    /** 0 = all, 1 = in progress, 2 = completed, 3 = failed */
    var tab by mutableIntStateOf(0)
    var category by mutableStateOf<String?>(null)

    var showAdd by mutableStateOf(false)
    var prefill by mutableStateOf("")

    /** Last clipboard link we already offered, so we do not nag. */
    var lastClip = ""

    // ---- security ----
    var locked by mutableStateOf(prefs.appLock && Security.available(app))
    var vaultUnlocked by mutableStateOf(false)
    var backgroundedAt = 0L

    // ---- video & music search ----
    var vQuery by mutableStateOf("")
    /** 0 = music (tap = MP3), 1 = video (tap = choose quality) */
    var vMode by mutableIntStateOf(0)
    var vSource by mutableStateOf(SearchSource.YOUTUBE)
    var vResults by mutableStateOf<List<SearchItem>>(emptyList())
    var vLoading by mutableStateOf(false)
    var vError by mutableStateOf<String?>(null)
    var vSheetItem by mutableStateOf<SearchItem?>(null)
    var vSheetMeta by mutableStateOf<VideoMeta?>(null)
    private var vJob: Job? = null

    fun runSearch() {
        val q = vQuery.trim()
        if (q.isEmpty()) return
        vJob?.cancel()
        vJob = viewModelScope.launch {
            vLoading = true
            vError = null
            vResults = emptyList()
            try {
                if (q.startsWith("http://") || q.startsWith("https://")) {
                    if (q.startsWith("http://") && !prefs.allowHttp) {
                        vError = "لینک http ناامن است. در تنظیمات می‌توانید اجازه بدهید."
                        return@launch
                    }
                    val meta = VideoEngine.inspect(q)
                    vSheetMeta = meta
                    vSheetItem = SearchItem("", meta.title, q, meta.uploader, meta.durationSec, meta.thumbnail)
                } else {
                    vResults = VideoEngine.search(q, vSource)
                    if (vResults.isEmpty()) vError = "نتیجه‌ای پیدا نشد"
                }
            } catch (ce: CancellationException) {
                throw ce
            } catch (t: Throwable) {
                vError = VideoEngine.friendlyError(t)
            } finally {
                vLoading = false
            }
        }
    }

    fun openQualitySheet(item: SearchItem) {
        vSheetMeta = null
        vSheetItem = item
    }

    fun openAdd(text: String = "") {
        prefill = text
        showAdd = true
    }
}
