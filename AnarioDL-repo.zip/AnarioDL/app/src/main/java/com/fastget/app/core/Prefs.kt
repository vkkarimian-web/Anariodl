package com.fastget.app.core

import android.content.Context
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf

/**
 * Settings backed by SharedPreferences, observable from Compose.
 *
 * Mutable settings use public `var` properties whose setters also persist to
 * SharedPreferences. From Kotlin, assign the property directly (e.g. `prefs.threads = 8`).
 *
 * `themeId` is read-only; mutation goes through `setTheme(...)` to match existing call sites.
 */
class Prefs(context: Context) {
    private val sp = context.getSharedPreferences("anario", Context.MODE_PRIVATE)

    private val themeIdState = mutableStateOf(sp.getString("theme", "midnight") ?: "midnight")
    val themeId: String get() = themeIdState.value

    fun setTheme(v: String) {
        themeIdState.value = v
        sp.edit().putString("theme", v).apply()
    }

    private val threadsState = mutableIntStateOf(sp.getInt("threads", 8))
    var threads: Int
        get() = threadsState.intValue
        set(v) {
            threadsState.intValue = v
            sp.edit().putInt("threads", v).apply()
        }

    private val maxParallelState = mutableIntStateOf(sp.getInt("parallel", 3))
    var maxParallel: Int
        get() = maxParallelState.intValue
        set(v) {
            maxParallelState.intValue = v
            sp.edit().putInt("parallel", v).apply()
        }

    /** KB/s, 0 = unlimited. Applied to downloads started after the change. */
    private val speedLimitKbState = mutableLongStateOf(sp.getLong("limit_kb", 0L))
    var speedLimitKb: Long
        get() = speedLimitKbState.longValue
        set(v) {
            speedLimitKbState.longValue = v
            sp.edit().putLong("limit_kb", v).apply()
        }

    private val wifiOnlyState = mutableStateOf(sp.getBoolean("wifi_only", false))
    var wifiOnly: Boolean
        get() = wifiOnlyState.value
        set(v) {
            wifiOnlyState.value = v
            sp.edit().putBoolean("wifi_only", v).apply()
        }

    private val clipboardWatchState = mutableStateOf(sp.getBoolean("clipboard", true))
    var clipboardWatch: Boolean
        get() = clipboardWatchState.value
        set(v) {
            clipboardWatchState.value = v
            sp.edit().putBoolean("clipboard", v).apply()
        }

    private val publishToDownloadsState = mutableStateOf(sp.getBoolean("publish", true))
    var publishToDownloads: Boolean
        get() = publishToDownloadsState.value
        set(v) {
            publishToDownloadsState.value = v
            sp.edit().putBoolean("publish", v).apply()
        }

    private val appLockState = mutableStateOf(sp.getBoolean("app_lock", false))
    var appLock: Boolean
        get() = appLockState.value
        set(v) {
            appLockState.value = v
            sp.edit().putBoolean("app_lock", v).apply()
        }

    private val secureScreenState = mutableStateOf(sp.getBoolean("secure_screen", false))
    var secureScreen: Boolean
        get() = secureScreenState.value
        set(v) {
            secureScreenState.value = v
            sp.edit().putBoolean("secure_screen", v).apply()
        }

    /** Plain http links are refused unless this is on. */
    private val allowHttpState = mutableStateOf(sp.getBoolean("allow_http", false))
    var allowHttp: Boolean
        get() = allowHttpState.value
        set(v) {
            allowHttpState.value = v
            sp.edit().putBoolean("allow_http", v).apply()
        }

    private val videoTermsAcceptedState = mutableStateOf(sp.getBoolean("video_terms", false))
    var videoTermsAccepted: Boolean
        get() = videoTermsAcceptedState.value
        private set(v) {
            videoTermsAcceptedState.value = v
            sp.edit().putBoolean("video_terms", v).apply()
        }

    val lastEngineUpdate: Long get() = sp.getLong("engine_update", 0L)

    fun acceptVideoTerms() {
        videoTermsAccepted = true
    }

    fun markEngineUpdated() {
        sp.edit().putLong("engine_update", System.currentTimeMillis()).apply()
    }

    /** "fa" | "en". Empty until first-run picker. */
    private val languageState = mutableStateOf(sp.getString("lang", "") ?: "")
    var language: String
        get() = languageState.value
        set(v) {
            languageState.value = v
            sp.edit().putString("lang", v).apply()
        }

    val languageChosen: Boolean get() = language.isNotBlank()

    /** Custom search prefixes, one per line: "label|ytsearch" or "label|scsearch" etc. */
    private val videoSourcesState = mutableStateOf(sp.getString("video_sources", "") ?: "")
    var videoSources: String
        get() = videoSourcesState.value
        set(v) {
            videoSourcesState.value = v
            sp.edit().putString("video_sources", v).apply()
        }

    private val musicSourcesState = mutableStateOf(sp.getString("music_sources", "") ?: "")
    var musicSources: String
        get() = musicSourcesState.value
        set(v) {
            musicSourcesState.value = v
            sp.edit().putString("music_sources", v).apply()
        }

    /** Global daily window: minutes from midnight, -1 = off. */
    private val scheduleStartMinState = mutableIntStateOf(sp.getInt("sched_start_min", -1))
    var scheduleStartMin: Int
        get() = scheduleStartMinState.intValue
        set(v) {
            scheduleStartMinState.intValue = v
            sp.edit().putInt("sched_start_min", v).apply()
        }

    private val scheduleStopMinState = mutableIntStateOf(sp.getInt("sched_stop_min", -1))
    var scheduleStopMin: Int
        get() = scheduleStopMinState.intValue
        set(v) {
            scheduleStopMinState.intValue = v
            sp.edit().putInt("sched_stop_min", v).apply()
        }

    fun isGlobalScheduleActive(now: Long = System.currentTimeMillis()): Boolean {
        val start = scheduleStartMin
        val stop = scheduleStopMin
        if (start < 0 && stop < 0) return true
        val cal = java.util.Calendar.getInstance()
        cal.timeInMillis = now
        val mins = cal.get(java.util.Calendar.HOUR_OF_DAY) * 60 + cal.get(java.util.Calendar.MINUTE)
        if (start >= 0 && stop >= 0) {
            return if (start <= stop) mins in start until stop else mins >= start || mins < stop
        }
        if (start >= 0) return mins >= start
        return mins < stop
    }

}
