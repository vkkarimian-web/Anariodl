package com.fastget.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.platform.LocalLayoutDirection

data class AppPalette(
    val id: String,
    val name: String,
    val dark: Boolean,
    val bg: Color,
    val surface: Color,
    val surfaceHigh: Color,
    val primary: Color,
    val secondary: Color,
    val text: Color,
    val textDim: Color
) {
    val onPrimary: Color get() = if (dark) bg else Color.White
}

val Palettes = listOf(
    AppPalette(
        "midnight", "شب‌آبی", true,
        bg = Color(0xFF0E1525), surface = Color(0xFF16213A), surfaceHigh = Color(0xFF1F2D4D),
        primary = Color(0xFF4C8DFF), secondary = Color(0xFF22D3EE),
        text = Color(0xFFE8EEFC), textDim = Color(0xFF93A1C4)
    ),
    AppPalette(
        "emerald", "زمرد", true,
        bg = Color(0xFF0A1814), surface = Color(0xFF11261F), surfaceHigh = Color(0xFF1A3A2F),
        primary = Color(0xFF2DD4A0), secondary = Color(0xFFA3E635),
        text = Color(0xFFE6F6EF), textDim = Color(0xFF8DB5A4)
    ),
    AppPalette(
        "amethyst", "ارغوانی", true,
        bg = Color(0xFF130F23), surface = Color(0xFF1D1736), surfaceHigh = Color(0xFF2B2250),
        primary = Color(0xFFA78BFA), secondary = Color(0xFFF472B6),
        text = Color(0xFFEFEAFE), textDim = Color(0xFFA79CC9)
    ),
    AppPalette(
        "amber", "کهربایی", true,
        bg = Color(0xFF15120D), surface = Color(0xFF221C13), surfaceHigh = Color(0xFF332A1B),
        primary = Color(0xFFF5A524), secondary = Color(0xFFFB7185),
        text = Color(0xFFF7EEDD), textDim = Color(0xFFBBAA8A)
    ),
    AppPalette(
        "daylight", "روز", false,
        bg = Color(0xFFF3F6FC), surface = Color(0xFFFFFFFF), surfaceHigh = Color(0xFFE4EAF7),
        primary = Color(0xFF2563EB), secondary = Color(0xFF0EA5E9),
        text = Color(0xFF0F172A), textDim = Color(0xFF5B6784)
    ),
    AppPalette(
        "glacier", "یخچالی", false,
        bg = Color(0xFFEDF6F5), surface = Color(0xFFFFFFFF), surfaceHigh = Color(0xFFD7EBE8),
        primary = Color(0xFF0F766E), secondary = Color(0xFF0369A1),
        text = Color(0xFF0B2B29), textDim = Color(0xFF4E6F6B)
    )
)

fun paletteOf(id: String): AppPalette = Palettes.firstOrNull { it.id == id } ?: Palettes[0]

val LocalPalette = staticCompositionLocalOf { Palettes[0] }

// Status colours stay constant across themes so their meaning never changes.
val ColorOk = Color(0xFF22C55E)
val ColorWarn = Color(0xFFF59E0B)
val ColorBad = Color(0xFFEF4444)

@Composable
fun FastGetTheme(palette: AppPalette, content: @Composable () -> Unit) {
    val scheme = if (palette.dark) {
        darkColorScheme(
            primary = palette.primary, onPrimary = palette.onPrimary,
            secondary = palette.secondary, onSecondary = palette.bg,
            background = palette.bg, onBackground = palette.text,
            surface = palette.surface, onSurface = palette.text,
            surfaceVariant = palette.surfaceHigh, onSurfaceVariant = palette.textDim,
            primaryContainer = palette.surfaceHigh, onPrimaryContainer = palette.text,
            outline = palette.textDim.copy(alpha = 0.45f),
            error = ColorBad
        )
    } else {
        lightColorScheme(
            primary = palette.primary, onPrimary = palette.onPrimary,
            secondary = palette.secondary, onSecondary = Color.White,
            background = palette.bg, onBackground = palette.text,
            surface = palette.surface, onSurface = palette.text,
            surfaceVariant = palette.surfaceHigh, onSurfaceVariant = palette.textDim,
            primaryContainer = palette.surfaceHigh, onPrimaryContainer = palette.text,
            outline = palette.textDim.copy(alpha = 0.45f),
            error = ColorBad
        )
    }
    CompositionLocalProvider(
        LocalLayoutDirection provides LayoutDirection.Rtl,
        LocalPalette provides palette
    ) {
        MaterialTheme(colorScheme = scheme, typography = Typography(), content = content)
    }
}
