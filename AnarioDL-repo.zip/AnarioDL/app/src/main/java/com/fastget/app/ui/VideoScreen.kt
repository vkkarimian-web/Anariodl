package com.fastget.app.ui

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.fastget.app.core.EngineState
import com.fastget.app.core.SearchItem
import com.fastget.app.core.SearchSource
import com.fastget.app.core.Security
import com.fastget.app.core.VideoEngine
import com.fastget.app.core.fa
import com.fastget.app.core.formatEta
import com.fastget.app.ui.theme.ColorBad

@Composable
fun VideoScreen(vm: MainViewModel) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val engine by VideoEngine.state.collectAsState()

    Column(Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.HOME }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
            }
            Text(
                "ویدیو و موسیقی",
                Modifier.weight(1f),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Bold
            )
        }

        OutlinedTextField(
            value = vm.vQuery,
            onValueChange = { vm.vQuery = it },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            placeholder = { Text("نام خواننده، آهنگ یا لینک ویدیو") },
            leadingIcon = { Icon(Icons.Rounded.Search, null) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { vm.runSearch() })
        )
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("موسیقی", "ویدیو").forEachIndexed { i, label ->
                FilterChip(
                    selected = vm.vMode == i, onClick = { vm.vMode = i },
                    label = { Text(label) }, colors = videoChipColors()
                )
            }
            Spacer(Modifier.width(8.dp))
            SearchSource.entries.forEach { s ->
                FilterChip(
                    selected = vm.vSource == s, onClick = { vm.vSource = s },
                    label = { Text(s.label) }, colors = videoChipColors()
                )
            }
        }
        Spacer(Modifier.height(10.dp))

        Box(Modifier.weight(1f).fillMaxWidth()) {
            when {
                engine is EngineState.Initializing -> Hint("در حال آماده‌سازی موتور ویدیو. بار اول چند ثانیه طول می‌کشد.")
                engine is EngineState.Failed -> Hint("موتور ویدیو بالا نیامد: ${(engine as EngineState.Failed).message}", ColorBad)
                vm.vLoading -> Column(
                    Modifier.fillMaxSize(),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center
                ) { CircularProgressIndicator(color = cs.primary) }
                vm.vError != null -> Hint(vm.vError!!, ColorBad)
                vm.vResults.isEmpty() -> Hint(
                    "نام خواننده یا آهنگ را بنویسید و جست‌وجو را بزنید، یا لینک ویدیو را بچسبانید. " +
                        "در حالت موسیقی با لمس نتیجه، MP3 دانلود می‌شود."
                )
                else -> LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = androidx.compose.foundation.layout.PaddingValues(bottom = 24.dp)
                ) {
                    items(vm.vResults, key = { it.url }) { item ->
                        ResultRow(
                            item,
                            onRowClick = {
                                if (vm.vMode == 0) {
                                    vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", false)
                                    Toast.makeText(ctx, "MP3 به صف دانلود اضافه شد", Toast.LENGTH_SHORT).show()
                                } else vm.openQualitySheet(item)
                            },
                            onMp3 = {
                                vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, "a:mp3", false)
                                Toast.makeText(ctx, "MP3 به صف دانلود اضافه شد", Toast.LENGTH_SHORT).show()
                            },
                            onVideo = { vm.openQualitySheet(item) }
                        )
                    }
                }
            }
        }
        Text(
            "فقط محتوایی را دانلود کنید که اجازهٔ استفاده‌اش را دارید.",
            style = MaterialTheme.typography.labelSmall,
            color = cs.onSurfaceVariant,
            modifier = Modifier.padding(vertical = 8.dp).navigationBarsPadding()
        )
    }

    vm.vSheetItem?.let { QualitySheet(vm, it) }

    if (!vm.prefs.videoTermsAccepted) {
        AlertDialog(
            onDismissRequest = { vm.screen = Screen.HOME },
            containerColor = cs.surface,
            title = { Text("قبل از شروع") },
            text = {
                Text(
                    "دانلود از بعضی سایت‌ها شرایط استفادهٔ آن‌ها را نقض می‌کند و دانلود محتوای دارای " +
                        "حق نشر بدون اجازه ممکن است غیرقانونی باشد. مسئولیت استفاده با خود شماست."
                )
            },
            confirmButton = { TextButton(onClick = { vm.prefs.acceptVideoTerms() }) { Text("متوجه شدم") } },
            dismissButton = { TextButton(onClick = { vm.screen = Screen.HOME }) { Text("بازگشت") } }
        )
    }
}

@Composable
private fun videoChipColors() = FilterChipDefaults.filterChipColors(
    containerColor = MaterialTheme.colorScheme.surface,
    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
    selectedContainerColor = MaterialTheme.colorScheme.primary,
    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
)

@Composable
private fun Hint(text: String, color: androidx.compose.ui.graphics.Color = MaterialTheme.colorScheme.onSurfaceVariant) {
    Box(Modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
        Text(text, color = color, style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun ResultRow(item: SearchItem, onRowClick: () -> Unit, onMp3: () -> Unit, onVideo: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        modifier = Modifier.fillMaxWidth().clickable(onClick = onRowClick)
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            AsyncImage(
                model = item.thumbnail,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.size(width = 104.dp, height = 58.dp)
                    .clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)
            )
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold
                )
                val dur = if (item.durationSec > 0) fa(formatEta(item.durationSec)) else ""
                Text(
                    listOf(item.uploader, dur).filter { it.isNotBlank() }.joinToString("  "),
                    maxLines = 1, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant
                )
            }
            IconButton(onClick = onMp3) { Icon(Icons.Rounded.MusicNote, "دانلود MP3", tint = cs.primary) }
            IconButton(onClick = onVideo) { Icon(Icons.Rounded.Movie, "دانلود ویدیو", tint = cs.secondary) }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun QualitySheet(vm: MainViewModel, item: SearchItem) {
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val sheet = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var priv by remember { mutableStateOf(false) }
    val canPrivate = remember { Security.available(ctx) }
    val heights = vm.vSheetMeta?.heights.orEmpty()

    val options = buildList {
        add("موسیقی MP3 با بهترین کیفیت" to "a:mp3")
        add("موسیقی M4A با حجم کمتر" to "a:m4a")
        listOf(1080, 720, 480, 360).forEach { h ->
            if (heights.isEmpty() || heights.any { it >= h }) add("ویدیو ${fa(h)}p" to "v:$h")
        }
        add("ویدیو با بهترین کیفیت موجود" to "v:best")
    }

    fun close() { vm.vSheetItem = null; vm.vSheetMeta = null }

    ModalBottomSheet(onDismissRequest = { close() }, sheetState = sheet, containerColor = cs.surface) {
        Column(Modifier.padding(horizontal = 20.dp).padding(bottom = 20.dp).navigationBarsPadding()) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AsyncImage(
                    model = item.thumbnail, contentDescription = null, contentScale = ContentScale.Crop,
                    modifier = Modifier.size(width = 96.dp, height = 54.dp)
                        .clip(RoundedCornerShape(10.dp)).background(cs.surfaceVariant)
                )
                Spacer(Modifier.width(12.dp))
                Text(
                    item.title, maxLines = 2, overflow = TextOverflow.Ellipsis,
                    style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold
                )
            }
            Spacer(Modifier.height(12.dp))
            options.forEach { (label, spec) ->
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
                        .background(cs.surfaceVariant.copy(alpha = 0.6f))
                        .clickable {
                            vm.manager.enqueueVideo(item.url, item.title, item.thumbnail, spec, priv && canPrivate)
                            Toast.makeText(ctx, "به صف دانلود اضافه شد", Toast.LENGTH_SHORT).show()
                            close()
                        }
                        .padding(horizontal = 14.dp, vertical = 13.dp)
                ) { Text(label, style = MaterialTheme.typography.bodyMedium) }
                Spacer(Modifier.height(8.dp))
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("ذخیره در پوشهٔ خصوصی", style = MaterialTheme.typography.bodyMedium)
                    Text(
                        if (canPrivate) "فقط با اثرانگشت یا قفل صفحه دیده می‌شود و در گالری نمی‌آید."
                        else "برای استفاده، اول قفل صفحهٔ گوشی را فعال کنید.",
                        style = MaterialTheme.typography.labelSmall, color = cs.onSurfaceVariant
                    )
                }
                Switch(
                    checked = priv && canPrivate, onCheckedChange = { priv = it }, enabled = canPrivate,
                    colors = SwitchDefaults.colors(checkedTrackColor = cs.primary, checkedThumbColor = cs.onPrimary)
                )
            }
        }
    }
}
