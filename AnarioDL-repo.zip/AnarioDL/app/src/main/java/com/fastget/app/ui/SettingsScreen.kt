package com.fastget.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.CheckCircle
import android.widget.Toast
import androidx.compose.material3.Button
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.fastget.app.core.EngineState
import com.fastget.app.core.Security
import com.fastget.app.core.VideoEngine
import kotlinx.coroutines.launch
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.fastget.app.core.fa
import com.fastget.app.ui.theme.AppPalette
import com.fastget.app.ui.theme.Palettes
import kotlin.math.roundToInt

@Composable
fun SettingsScreen(vm: MainViewModel) {
    val p = vm.prefs
    val cs = MaterialTheme.colorScheme
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val engine by VideoEngine.state.collectAsState()

    Column(
        Modifier.fillMaxSize().statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp)
            .padding(bottom = 32.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = { vm.screen = Screen.HOME }) {
                Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = "بازگشت")
            }
            Text("تنظیمات", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        }

        Section("تم رنگی")
        Palettes.chunked(2).forEach { row ->
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                row.forEach { pal ->
                    ThemeCard(pal, selected = p.themeId == pal.id, modifier = Modifier.weight(1f)) {
                        p.setTheme(pal.id)
                    }
                }
                if (row.size == 1) Spacer(Modifier.weight(1f))
            }
        }

        Section("سرعت و اتصال")
        SettingBlock {
            Text("تعداد بخش‌های هر دانلود: ${fa(p.threads)}", style = MaterialTheme.typography.bodyLarge)
            Text(
                "فایل به همین تعداد تکه تقسیم و هم‌زمان دریافت می‌شود. روی دانلودهای جدید اعمال می‌شود.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
            Slider(
                value = p.threads.toFloat(),
                onValueChange = { p.threads = it.roundToInt() },
                valueRange = 1f..16f, steps = 14,
                colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
            )
        }
        SettingBlock {
            Text("دانلود هم‌زمان: ${fa(p.maxParallel)}", style = MaterialTheme.typography.bodyLarge)
            Slider(
                value = p.maxParallel.toFloat(),
                onValueChange = { p.maxParallel = it.roundToInt() },
                valueRange = 1f..5f, steps = 3,
                colors = SliderDefaults.colors(thumbColor = cs.primary, activeTrackColor = cs.primary)
            )
        }
        SettingBlock {
            Text("محدودیت سرعت هر دانلود", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(
                    0L to "نامحدود", 512L to "۵۱۲ کیلوبایت", 1024L to "۱ مگابایت",
                    2048L to "۲ مگابایت", 5120L to "۵ مگابایت"
                ).forEach { (kb, label) ->
                    FilterChip(
                        selected = p.speedLimitKb == kb,
                        onClick = { p.speedLimitKb = kb },
                        label = { Text(label) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = cs.primary, selectedLabelColor = cs.onPrimary
                        )
                    )
                }
            }
        }
        SwitchRow("فقط با وای‌فای دانلود کن", p.wifiOnly) { p.wifiOnly = it }

        Section("رفتار برنامه")
        SwitchRow("تشخیص لینک کپی‌شده", p.clipboardWatch) { p.clipboardWatch = it }
        SwitchRow("انتقال فایل کامل‌شده به پوشهٔ Download/FastGet", p.publishToDownloads) {
            p.publishToDownloads = it
        }

        Section("امنیت و حریم خصوصی")
        SwitchRow("قفل برنامه با اثرانگشت یا قفل صفحه", p.appLock) { on ->
            if (on && !Security.available(ctx)) {
                Toast.makeText(ctx, "اول در تنظیمات گوشی یک قفل صفحه یا اثرانگشت فعال کنید", Toast.LENGTH_LONG).show()
            } else p.appLock = on
        }
        SwitchRow("جلوگیری از اسکرین‌شات و پنهان‌کردن برنامه در لیست اخیر", p.secureScreen) {
            p.secureScreen = it
        }
        SwitchRow("اجازهٔ لینک‌های http (بدون رمزنگاری)", p.allowHttp) { p.allowHttp = it }
        Text(
            "پوشهٔ خصوصی همیشه قفل شخصی دارد و فایل‌هایش در گالری و پوشهٔ Download دیده نمی‌شود.",
            style = MaterialTheme.typography.bodySmall,
            color = cs.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 6.dp)
        )

        Section("موتور ویدیو")
        SettingBlock {
            Text(
                when (engine) {
                    is EngineState.Ready -> "آماده"
                    is EngineState.Initializing -> "در حال آماده‌سازی…"
                    is EngineState.Failed -> "خطا: " + (engine as EngineState.Failed).message
                },
                style = MaterialTheme.typography.bodyLarge
            )
            Text(
                "سایت‌ها مدام تغییر می‌کنند. اگر دانلودی ناموفق شد، موتور را به‌روزرسانی کنید. هر سه روز یک‌بار هم خودکار بررسی می‌شود.",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
            Spacer(Modifier.height(10.dp))
            Button(
                enabled = engine is EngineState.Ready,
                onClick = {
                    scope.launch {
                        val msg = try {
                            VideoEngine.update(ctx).also { p.markEngineUpdated() }
                        } catch (t: Throwable) {
                            VideoEngine.friendlyError(t)
                        }
                        Toast.makeText(ctx, msg, Toast.LENGTH_LONG).show()
                    }
                }
            ) { Text("به‌روزرسانی موتور ویدیو") }
        }
    }
}

@Composable
private fun Section(title: String) {
    Text(
        title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.SemiBold,
        color = MaterialTheme.colorScheme.primary,
        modifier = Modifier.padding(top = 18.dp, bottom = 10.dp)
    )
}

@Composable
private fun SettingBlock(content: @Composable () -> Unit) {
    Column(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(MaterialTheme.colorScheme.surface)
            .padding(16.dp)
    ) { content() }
}

@Composable
private fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().padding(bottom = 10.dp)
            .clip(RoundedCornerShape(18.dp))
            .background(cs.surface)
            .clickable { onChange(!checked) }
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        Switch(
            checked = checked, onCheckedChange = onChange,
            colors = SwitchDefaults.colors(checkedTrackColor = cs.primary, checkedThumbColor = cs.onPrimary)
        )
    }
}

@Composable
private fun ThemeCard(pal: AppPalette, selected: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Box(
        modifier
            .height(96.dp)
            .clip(shape)
            .background(pal.bg)
            .border(
                BorderStroke(if (selected) 2.5.dp else 1.dp, if (selected) pal.primary else pal.textDim.copy(alpha = 0.35f)),
                shape
            )
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.SpaceBetween) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf(pal.primary, pal.secondary, pal.surfaceHigh).forEach {
                    Box(Modifier.size(18.dp).clip(CircleShape).background(it))
                }
            }
            Text(pal.name, color = pal.text, fontWeight = FontWeight.SemiBold)
        }
        if (selected) {
            Icon(
                Icons.Rounded.CheckCircle, null, tint = pal.primary,
                modifier = Modifier.align(Alignment.TopStart).size(22.dp)
            )
        }
    }
}
