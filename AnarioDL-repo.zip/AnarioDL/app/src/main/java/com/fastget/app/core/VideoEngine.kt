package com.fastget.app.core

import android.app.Application
import android.content.Context
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException

sealed interface EngineState {
    data object Initializing : EngineState
    data object Ready : EngineState
    data class Failed(val message: String) : EngineState
}

enum class SearchSource(val prefix: String, val label: String) {
    YOUTUBE("ytsearch", "یوتیوب"),
    SOUNDCLOUD("scsearch", "ساندکلود")
}

data class SearchItem(
    val id: String,
    val title: String,
    val url: String,
    val uploader: String,
    val durationSec: Long,
    val thumbnail: String?
)

data class VideoMeta(
    val title: String,
    val uploader: String,
    val durationSec: Long,
    val thumbnail: String?,
    val heights: List<Int>,
    val site: String
)

/**
 * Thin wrapper around the yt-dlp Android library (youtubedl-android).
 *
 * Every call into the third-party API is in THIS file. If a library update changes a
 * signature, this is the only place that needs fixing:
 *  - YoutubeDL.getInstance().init / execute / destroyProcessById / updateYoutubeDL
 *  - FFmpeg.getInstance().init
 *
 * Security notes: the only user-controlled values are the URL and the search text. URLs must
 * start with http(s)://, and search text is always glued to a "ytsearchN:" prefix, so neither
 * can ever be read by yt-dlp as a command-line option.
 */
object VideoEngine {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val _state = MutableStateFlow<EngineState>(EngineState.Initializing)
    val state: StateFlow<EngineState> = _state

    private const val THREE_DAYS = 3L * 24 * 3600 * 1000

    fun initAsync(app: Application, prefs: Prefs) {
        scope.launch {
            try {
                YoutubeDL.getInstance().init(app)
                FFmpeg.getInstance().init(app)
                _state.value = EngineState.Ready
            } catch (t: Throwable) {
                _state.value = EngineState.Failed(t.message ?: "خطای ناشناخته")
                return@launch
            }
            // Sites change often; keeping yt-dlp fresh is what keeps downloads working.
            if (System.currentTimeMillis() - prefs.lastEngineUpdate > THREE_DAYS) {
                runCatching {
                    update(app)
                    prefs.markEngineUpdated()
                }
            }
        }
    }

    private suspend fun ready() {
        val s = _state.first { it !is EngineState.Initializing }
        if (s is EngineState.Failed) throw IOException("موتور ویدیو آماده نیست: ${s.message}")
    }

    private fun requireHttp(url: String) {
        if (!(url.startsWith("https://") || url.startsWith("http://"))) {
            throw IOException("فقط لینک http و https پذیرفته می‌شود")
        }
    }

    // ---------------- search ----------------

    suspend fun search(query: String, source: SearchSource, count: Int = 15): List<SearchItem> =
        withContext(Dispatchers.IO) {
            ready()
            val q = query.trim().replace('\n', ' ').replace('\r', ' ').take(120)
            val req = YoutubeDLRequest("${source.prefix}$count:$q")
            req.addOption("--flat-playlist")
            req.addOption("-J")
            req.addOption("--no-warnings")
            req.addOption("--socket-timeout", "15")
            val out = YoutubeDL.getInstance().execute(req).out
            val start = out.indexOf('{')
            if (start < 0) return@withContext emptyList()
            val arr = JSONObject(out.substring(start)).optJSONArray("entries")
                ?: return@withContext emptyList()

            buildList {
                for (i in 0 until arr.length()) {
                    val o = arr.optJSONObject(i) ?: continue
                    val id = o.optString("id")
                    val url = o.optString("webpage_url").ifBlank { o.optString("url") }
                    if (!url.startsWith("http")) continue
                    val isYoutube = url.contains("youtube.com") || url.contains("youtu.be")
                    val thumb = when {
                        isYoutube && id.isNotBlank() -> "https://i.ytimg.com/vi/$id/mqdefault.jpg"
                        else -> o.optJSONArray("thumbnails")
                            ?.let { t -> t.optJSONObject(t.length() - 1)?.optString("url") }
                            ?.takeIf { it.startsWith("http") }
                            ?: o.optString("thumbnail").takeIf { it.startsWith("http") }
                    }
                    add(
                        SearchItem(
                            id = id,
                            title = o.optString("title").ifBlank { "بدون عنوان" },
                            url = url,
                            uploader = o.optString("uploader").ifBlank { o.optString("channel") },
                            durationSec = o.optDouble("duration", 0.0).toLong(),
                            thumbnail = thumb
                        )
                    )
                }
            }
        }

    // ---------------- inspect a pasted link ----------------

    suspend fun inspect(url: String): VideoMeta = withContext(Dispatchers.IO) {
        ready()
        requireHttp(url)
        val req = YoutubeDLRequest(url)
        req.addOption("-J")
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--socket-timeout", "20")
        val out = YoutubeDL.getInstance().execute(req).out
        val start = out.indexOf('{')
        if (start < 0) throw IOException("اطلاعاتی از این لینک گرفته نشد")
        val o = JSONObject(out.substring(start))
        val heights = mutableSetOf<Int>()
        o.optJSONArray("formats")?.let { f ->
            for (i in 0 until f.length()) {
                val h = f.optJSONObject(i)?.optInt("height", 0) ?: 0
                if (h > 0) heights.add(h)
            }
        }
        VideoMeta(
            title = o.optString("title").ifBlank { "بدون عنوان" },
            uploader = o.optString("uploader").ifBlank { o.optString("channel") },
            durationSec = o.optDouble("duration", 0.0).toLong(),
            thumbnail = o.optString("thumbnail").takeIf { it.startsWith("http") },
            heights = heights.sortedDescending(),
            site = o.optString("extractor_key")
        )
    }

    // ---------------- download ----------------

    /**
     * spec: "a:mp3" | "a:m4a" | "v:<height>" | "v:best".
     * Output goes to [dir] using the video title; call [pickOutput] afterwards.
     * [onProgress] receives (percent 0..100, etaSeconds, bytesPerSec).
     */
    suspend fun download(
        url: String,
        spec: String,
        dir: File,
        processId: String,
        onProgress: (Float, Long, Long) -> Unit
    ) = withContext(Dispatchers.IO) {
        ready()
        requireHttp(url)
        val req = YoutubeDLRequest(url)
        req.addOption("--no-playlist")
        req.addOption("--newline")
        req.addOption("--no-mtime")
        req.addOption("--windows-filenames")
        req.addOption("--trim-filenames", "120")
        req.addOption("--retries", "10")
        req.addOption("--fragment-retries", "10")
        req.addOption("--socket-timeout", "20")
        req.addOption("-N", "4")
        // Resume partials after CDN URL refresh / re-extract (same output dir).
        req.addOption("--continue")
        req.addOption("--no-overwrites")
        req.addOption("-o", dir.absolutePath + "/%(title)s.%(ext)s")

        if (spec.startsWith("a:")) {
            val fmt = if (spec == "a:m4a") "m4a" else "mp3"
            req.addOption("-f", if (fmt == "m4a") "bestaudio[ext=m4a]/bestaudio" else "bestaudio/best")
            req.addOption("-x")
            req.addOption("--audio-format", fmt)
            req.addOption("--audio-quality", "0")
            req.addOption("--embed-metadata")
            // Cover art inside the file. If a site makes this fail, delete these two lines.
            req.addOption("--embed-thumbnail")
            req.addOption("--convert-thumbnails", "jpg")
        } else {
            val h = spec.removePrefix("v:").toIntOrNull()
            val selector = if (h == null) {
                "bv*[ext=mp4]+ba[ext=m4a]/b[ext=mp4]/bv*+ba/b"
            } else {
                "bv*[height<=$h][ext=mp4]+ba[ext=m4a]/b[height<=$h][ext=mp4]/" +
                    "bv*[height<=$h]+ba/b[height<=$h]/b"
            }
            req.addOption("-f", selector)
            req.addOption("--merge-output-format", "mp4")
            req.addOption("--embed-metadata")
        }

        YoutubeDL.getInstance().execute(
            request = req,
            processId = processId,
            callback = { progress, eta, line -> onProgress(progress, eta, parseSpeed(line)) }
        )
    }

    fun cancel(processId: String) {
        runCatching { YoutubeDL.getInstance().destroyProcessById(processId) }
    }

    /** Biggest finished file in [dir] (ignores partial and temp files). */
    fun pickOutput(dir: File): File? =
        dir.listFiles()
            ?.filter {
                it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") &&
                    !it.name.endsWith(".temp") && !it.name.contains(".part-Frag")
            }
            ?.maxByOrNull { it.length() }

    // ---------------- engine update ----------------

    suspend fun update(app: Context): String = withContext(Dispatchers.IO) {
        ready()
        // UpdateChannel / UpdateStatus are nested on YoutubeDL (0.16+).
        // Compare by toString/name so a minor library rename does not break the build.
        val st = YoutubeDL.getInstance().updateYoutubeDL(app, YoutubeDL.UpdateChannel.STABLE)
        val key = st?.toString().orEmpty()
        when {
            key.contains("DONE") && !key.contains("ALREADY") -> "موتور ویدیو به‌روزرسانی شد"
            key.contains("ALREADY_UP_TO_DATE") -> "موتور ویدیو از قبل به‌روز است"
            else -> "بررسی به‌روزرسانی انجام شد"
        }
    }

    // ---------------- helpers ----------------

    private val speedRe = Regex("""at\s+([\d.]+)\s*([KMG]?)i?B/s""")

    private fun parseSpeed(line: String): Long {
        val m = speedRe.find(line) ?: return 0
        val v = m.groupValues[1].toDoubleOrNull() ?: return 0
        val mult = when (m.groupValues[2]) {
            "K" -> 1024.0
            "M" -> 1024.0 * 1024
            "G" -> 1024.0 * 1024 * 1024
            else -> 1.0
        }
        return (v * mult).toLong()
    }

    /** Turns raw yt-dlp errors into short Persian messages. */
    fun friendlyError(t: Throwable): String {
        val raw = t.message.orEmpty()
        return when {
            raw.contains("Unsupported URL", true) -> "این لینک پشتیبانی نمی‌شود"
            raw.contains("Private video", true) || raw.contains("Video unavailable", true) ->
                "ویدیو در دسترس نیست یا خصوصی است"
            raw.contains("Sign in", true) || raw.contains("age", true) && raw.contains("confirm", true) ->
                "این ویدیو نیاز به ورود یا تأیید سن دارد"
            raw.contains("429") -> "سرور محدودیت زده؛ کمی بعد دوباره امتحان کنید"
            raw.contains("Unable to extract", true) || raw.contains("unable to download", true) ->
                "استخراج ناموفق بود؛ از تنظیمات، موتور ویدیو را به‌روزرسانی کنید"
            raw.contains("Unable to resolve host", true) || raw.contains("timed out", true) ->
                "اتصال اینترنت برقرار نیست"
            else -> raw.lines().lastOrNull { it.contains("ERROR", true) }?.take(160)
                ?: raw.take(160).ifBlank { "خطای ناشناخته" }
        }
    }
}
