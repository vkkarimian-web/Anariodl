# Anario DL — آناریو

Lightweight Android download manager (arm64). Version 3.

## Features

- Multi-thread HTTP downloads with resume
- Video/music via yt-dlp (YouTube, Instagram, SoundCloud, and many other sites)
- Auto CDN link refresh on 403/expiry (up to 3 retries) + continue partial files
- File details: manual URL, custom path, priority, size, ETA, play/pause
- Global schedule window (start/stop kill-switch)
- Queue priority
- App lock / private vault
- Bilingual FA/EN (picker on first launch)
  - Persian: **آناریو**
  - English: **Anario DL**

## Build

```bash
./gradlew clean
./gradlew :app:assembleRelease
```

Output:

```text
app/build/outputs/apk/release/app-arm64-v8a-release.apk
```

- `applicationId`: `com.anario.dl`
- ABI: **arm64-v8a only**

## GitHub Actions

Push to `main` / `master` or run the workflow manually.

Artifact: **AnarioDL-v3.zip**
