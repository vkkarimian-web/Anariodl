package com.fastget.app.ui

import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.CloudDownload
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.FolderOpen
import androidx.compose.material.icons.rounded.FolderZip
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material.icons.rounded.InsertDriveFile
import androidx.compose.material.icons.rounded.MoreVert
import androidx.compose.material.icons.rounded.Movie
import androidx.compose.material.icons.rounded.MusicNote
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExtendedFloatingActionButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.fastget.app.core.Category
import com.fastget.app.core.Live
import com.fastget.app.core.Segments
import com.fastget.app.core.fa
import com.fastget.app.core.formatBytes
import com.fastget.app.core.formatEta
import com.fastget.app.core.formatSpeed
import com.fastget.app.core.mimeOf
import com.fastget.app.data.DownloadEntity
import com.fastget.app.data.Kind
import com.fastget.app.data.Status
import coil.compose.AsyncImage
import androidx.compose.ui.layout.ContentScale
import com.fastget.app.ui.theme.ColorBad
import com.fastget.app.ui.theme.ColorOk
import com.fastget.app.ui.theme.ColorWarn
import com.fastget.app.ui.theme.LocalPalette
import java.io.File

@Composable
fun App(vm: MainViewModel, auth: AuthFn) {
    val prefs = vm.prefs
    if (!prefs.languageChosen) {
        LanguagePicker(onPick = { prefs.language = it })
        return
    }
    val title = com.fastget.app.core.I18n.appTitle(prefs)
    if (vm.locked) {
        LockScreen(auth = { auth(title) { vm.locked = false } })
        return
    }
    BackHandler(enabled = vm.screen != Screen.HOME) { vm.screen = Screen.HOME }
    when (vm.screen) {
        Screen.HOME -> HomeScreen(vm)
        Screen.SETTINGS -> SettingsScreen(vm)
        Screen.VIDEO -> VideoScreen(vm)
        Screen.VAULT -> VaultScreen(vm, auth)
    }
    if (vm.showAdd) AddSheet(vm)
}

@Composable
private fun LanguagePicker(onPick: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp),
            modifier = Modifier.padding(32.dp),
        ) {
            Text("FastGet", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
            Text("زبان / Language", color = cs.onSurfaceVariant)
            Button(onClick = { onPick("fa") }, modifier = Modifier.fillMaxWidth(0.7f)) {
                Text("فارسی — فست‌گت")
            }
            Button(onClick = { onPick("en") }, modifier = Modifier.fillMaxWidth(0.7f)) {
                Text("English — FastGet")
            }
        }
    }
}

@Composable
fun HomeScreen(vm: MainViewModel) {
    val all by vm.downloads.collectAsStateWithLifecycle()
    val items = all.filter { !it.isPrivate }
    val live by vm.live.collectAsStateWithLifecycle()
    var detail by remember { mutableStateOf<DownloadEntity?>(null) }
    var confirm by remember { mutableStateOf<DownloadEntity?>(null) }
    val cs = MaterialTheme.colorScheme

    val filtered = items.filter { e ->
        val okTab = when (vm.tab) {
            0 -> true
            1 -> e.status == Status.DOWNLOADING || e.status == Status.QUEUED || e.status == Status.PAUSED
            2 -> e.status == Status.COMPLETED
            else -> e.status == Status.FAILED
        }
        okTab && (vm.category == null || e.category == vm.category)
    }
    val activeCount = items.count { it.status == Status.DOWNLOADING }
    val queuedCount = items.count { it.status == Status.QUEUED }
    val doneCount = items.count { it.status == Status.COMPLETED }
    val speed = live.values.sumOf { it.speed }

    Scaffold(
        containerColor = cs.background,
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { vm.openAdd() },
                icon = { Icon(Icons.Rounded.Add, contentDescription = null) },
                text = { Text("افزودن لینک", fontWeight = FontWeight.SemiBold) },
                containerColor = cs.primary,
                contentColor = cs.onPrimary
            )
        }
    ) { pad ->
        LazyColumn(
            modifier = Modifier.padding(pad).fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { HeaderRow(vm) }
            item { SearchEntry(onClick = { vm.screen = Screen.VIDEO }) }
            item { StatusChips(vm) }
            item { CategoryChips(vm) }

            if (filtered.isEmpty()) {
                item { EmptyState() }
            }
            items(filtered, key = { it.id }) { e ->
                DownloadCard(
                    e, live[e.id], vm,
                    onDelete = { confirm = e },
                    onOpen = { detail = e },
                )
            }
        }
    }

    confirm?.let { e ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            containerColor = cs.surface,
            title = { Text("حذف دانلود") },
            text = { Text(e.fileName, maxLines = 2, overflow = TextOverflow.Ellipsis) },
            confirmButton = {
                TextButton(onClick = { vm.manager.delete(e.id, true); confirm = null }) {
                    Text("حذف همراه فایل", color = ColorBad)
                }
            },
            dismissButton = {
                TextButton(onClick = { vm.manager.delete(e.id, false); confirm = null }) {
                    Text("فقط از فهرست")
                }
            }
        )
    }

    detail?.let { d ->
        val lv = live[d.id]
        DetailsSheet(
            e = d,
            liveSpeed = lv?.speed ?: 0L,
            liveEta = lv?.etaSec ?: -1L,
            vm = vm,
            onDismiss = { detail = null },
        )
    }
}

@Composable
private fun HeaderRow(vm: MainViewModel) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text("فست‌گت", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(
                "مدیر دانلود چندتکه",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
        IconButton(onClick = { vm.screen = Screen.VAULT }) {
            Icon(Icons.Rounded.Lock, contentDescription = "پوشهٔ خصوصی")
        }
        IconButton(onClick = { vm.screen = Screen.SETTINGS }) {
            Icon(Icons.Rounded.Settings, contentDescription = "تنظیمات")
        }
        var more by remember { mutableStateOf(false) }
        Box {
            IconButton(onClick = { more = true }) { Icon(Icons.Rounded.MoreVert, contentDescription = "بیشتر") }
            DropdownMenu(expanded = more, onDismissRequest = { more = false }) {
                DropdownMenuItem(
                    text = { Text("توقف همه") },
                    leadingIcon = { Icon(Icons.Rounded.PauseCircle, null) },
                    onClick = { more = false; vm.manager.pauseAll() }
                )
                DropdownMenuItem(
                    text = { Text("ادامهٔ همه") },
                    leadingIcon = { Icon(Icons.Rounded.PlayArrow, null) },
                    onClick = { more = false; vm.manager.resumeAll() }
                )
            }
        }
    }
}

@Composable
private fun SummaryCard(speed: Long, active: Int, queued: Int, done: Int) {
    val pal = LocalPalette.current
    val fg = pal.onPrimary
    Box(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .background(Brush.horizontalGradient(listOf(pal.primary, pal.secondary)))
            .padding(20.dp)
    ) {
        Column {
            Text("سرعت کل", color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.labelLarge)
            Text(
                fa(formatSpeed(speed)),
                color = fg,
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold
            )
            Spacer(Modifier.height(16.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Stat("فعال", active, fg)
                Stat("در صف", queued, fg)
                Stat("تمام‌شده", done, fg)
            }
        }
    }
}

@Composable
private fun SearchEntry(onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(cs.surface)
            .clickable(onClick = onClick).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Rounded.Search, null, tint = cs.primary)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text("جستجوی موسیقی و ویدیو", fontWeight = FontWeight.SemiBold)
            Text(
                "اسم خواننده یا آهنگ را بنویسید یا لینک یوتیوب و سایت‌های ویدیویی را بچسبانید",
                style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant
            )
        }
    }
}

@Composable
private fun Stat(label: String, value: Int, fg: Color) {
    Column(horizontalAlignment = Alignment.Start) {
        Text(fa(value), color = fg, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        Text(label, color = fg.copy(alpha = 0.8f), style = MaterialTheme.typography.labelMedium)
    }
}

@Composable
private fun StatusChips(vm: MainViewModel) {
    val tabs = listOf("همه", "در حال انجام", "تمام‌شده", "ناموفق")
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        itemsIndexed(tabs) { i, label ->
            FilterChip(
                selected = vm.tab == i,
                onClick = { vm.tab = i },
                label = { Text(label) },
                colors = chipColors()
            )
        }
    }
}

@Composable
private fun CategoryChips(vm: MainViewModel) {
    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        item {
            FilterChip(
                selected = vm.category == null,
                onClick = { vm.category = null },
                label = { Text("همهٔ دسته‌ها") },
                colors = chipColors()
            )
        }
        items(Category.all) { c ->
            FilterChip(
                selected = vm.category == c,
                onClick = { vm.category = if (vm.category == c) null else c },
                label = { Text(Category.label(c)) },
                colors = chipColors()
            )
        }
    }
}

@Composable
private fun chipColors() = FilterChipDefaults.filterChipColors(
    containerColor = MaterialTheme.colorScheme.surface,
    labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
    selectedContainerColor = MaterialTheme.colorScheme.primary,
    selectedLabelColor = MaterialTheme.colorScheme.onPrimary
)

@Composable
private fun EmptyState() {
    Column(
        Modifier.fillMaxWidth().padding(vertical = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            Icons.Rounded.CloudDownload, null,
            Modifier.size(56.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Spacer(Modifier.height(12.dp))
        Text("دانلودی در این فهرست نیست", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(4.dp))
        Text(
            "با «افزودن لینک» شروع کنید یا در مرورگر از گزینهٔ اشتراک‌گذاری، فست‌گت را انتخاب کنید.",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center
        )
    }
}

private fun categoryStyle(c: String): Pair<ImageVector, Color> = when (c) {
    Category.VIDEO -> Icons.Rounded.Movie to Color(0xFFF43F5E)
    Category.AUDIO -> Icons.Rounded.MusicNote to Color(0xFFA855F7)
    Category.DOCUMENT -> Icons.Rounded.Description to Color(0xFF3B82F6)
    Category.ARCHIVE -> Icons.Rounded.FolderZip to Color(0xFFF59E0B)
    Category.APP -> Icons.Rounded.Apps to Color(0xFF22C55E)
    Category.IMAGE -> Icons.Rounded.Image to Color(0xFF06B6D4)
    else -> Icons.Rounded.InsertDriveFile to Color(0xFF94A3B8)
}

private fun statusText(e: DownloadEntity): String = when (e.status) {
    Status.DOWNLOADING ->
        if (e.totalBytes > 0) "${fa((e.downloadedBytes * 100 / e.totalBytes).toInt())}٪ دریافت شد"
        else "در حال دریافت"
    Status.QUEUED -> "در صف انتظار"
    Status.PAUSED -> "متوقف شده"
    Status.FAILED -> e.error ?: "ناموفق"
    else -> fa(formatBytes(e.totalBytes))
}

@Composable
private fun statusColor(status: String): Color = when (status) {
    Status.DOWNLOADING -> MaterialTheme.colorScheme.primary
    Status.COMPLETED -> ColorOk
    Status.FAILED -> ColorBad
    Status.PAUSED -> ColorWarn
    else -> MaterialTheme.colorScheme.onSurfaceVariant
}

@Composable
internal fun DownloadCard(e: DownloadEntity, live: Live?, vm: MainViewModel, onDelete: () -> Unit, onOpen: () -> Unit = {}) {
    val ctx = LocalContext.current
    val cs = MaterialTheme.colorScheme
    val (icon, color) = categoryStyle(e.category)
    var menu by remember { mutableStateOf(false) }

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = cs.surface),
        modifier = Modifier.clickable(onClick = onOpen),
    ) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (e.thumbnail != null) {
                    AsyncImage(
                        model = e.thumbnail, contentDescription = null, contentScale = ContentScale.Crop,
                        modifier = Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                            .background(color.copy(alpha = 0.16f))
                    )
                } else {
                    Box(
                        Modifier.size(46.dp).clip(RoundedCornerShape(14.dp))
                            .background(color.copy(alpha = 0.16f)),
                        contentAlignment = Alignment.Center
                    ) { Icon(icon, null, tint = color) }
                }
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        e.fileName,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        statusText(e),
                        style = MaterialTheme.typography.bodySmall,
                        color = statusColor(e.status)
                    )
                }
                PrimaryAction(e, vm, ctx)
                Box {
                    IconButton(onClick = { menu = true }) {
                        Icon(Icons.Rounded.MoreVert, contentDescription = "بیشتر")
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        DropdownMenuItem(
                            text = { Text("کپی لینک") },
                            onClick = {
                                menu = false
                                vm.lastClip = e.url
                                ctx.getSystemService(ClipboardManager::class.java)
                                    .setPrimaryClip(ClipData.newPlainText("url", e.url))
                                Toast.makeText(ctx, "لینک کپی شد", Toast.LENGTH_SHORT).show()
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("شروع مجدد از صفر") },
                            onClick = { menu = false; vm.manager.restart(e.id) }
                        )
                        DropdownMenuItem(
                            text = { Text("حذف", color = ColorBad) },
                            onClick = { menu = false; onDelete() }
                        )
                    }
                }
            }

            if (e.status != Status.COMPLETED) {
                Spacer(Modifier.height(10.dp))
                if (e.totalBytes > 0) {
                    SegmentBar(e)
                } else if (e.status == Status.DOWNLOADING) {
                    LinearProgressIndicator(
                        Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                        color = cs.primary, trackColor = cs.surfaceVariant
                    )
                }
                Spacer(Modifier.height(6.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    val left = when {
                        e.kind == Kind.VIDEO -> "${fa((e.downloadedBytes * 100 / e.totalBytes.coerceAtLeast(1)).toInt())}٪"
                        e.totalBytes > 0 -> "${fa(formatBytes(e.downloadedBytes))} از ${fa(formatBytes(e.totalBytes))}"
                        else -> fa(formatBytes(e.downloadedBytes))
                    }
                    Text(left, style = MaterialTheme.typography.labelMedium, color = cs.onSurfaceVariant)
                    if (e.status == Status.DOWNLOADING && live != null) {
                        val eta = if (live.etaSec >= 0) "  ${fa(formatEta(live.etaSec))}" else ""
                        Text(
                            fa(formatSpeed(live.speed)) + eta,
                            style = MaterialTheme.typography.labelMedium,
                            color = cs.primary
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PrimaryAction(e: DownloadEntity, vm: MainViewModel, ctx: Context) {
    when (e.status) {
        Status.DOWNLOADING, Status.QUEUED ->
            IconButton(onClick = { vm.manager.pause(e.id) }) {
                Icon(Icons.Rounded.Pause, contentDescription = "توقف")
            }
        Status.PAUSED ->
            IconButton(onClick = { vm.manager.resume(e.id) }) {
                Icon(Icons.Rounded.PlayArrow, contentDescription = "ادامه")
            }
        Status.FAILED ->
            IconButton(onClick = { vm.manager.retry(e.id) }) {
                Icon(Icons.Rounded.Refresh, contentDescription = "تلاش دوباره")
            }
        else ->
            IconButton(onClick = { openDownload(ctx, e) }) {
                Icon(Icons.Rounded.FolderOpen, contentDescription = "باز کردن")
            }
    }
}

/** Draws one slice per segment, so you can see the parallel connections filling in. */
@Composable
private fun SegmentBar(e: DownloadEntity) {
    val pal = LocalPalette.current
    val cs = MaterialTheme.colorScheme
    val segs = remember(e.segments) { Segments.decode(e.segments) }
    Canvas(Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp))) {
        val rtl = layoutDirection == LayoutDirection.Rtl
        val total = e.totalBytes.toFloat().coerceAtLeast(1f)
        drawRect(cs.surfaceVariant)

        fun slice(startFrac: Float, widthFrac: Float, c: Color) {
            val w = (size.width * widthFrac).coerceAtLeast(0f)
            val x = size.width * startFrac
            drawRect(c, Offset(if (rtl) size.width - x - w else x, 0f), Size(w, size.height))
        }

        if (segs.isEmpty()) {
            slice(0f, e.downloadedBytes / total, pal.primary)
        } else {
            segs.forEachIndexed { i, s ->
                slice(s.start / total, s.done.get() / total, if (i % 2 == 0) pal.primary else pal.secondary)
            }
            segs.drop(1).forEach { s ->
                slice(s.start / total, 1.5f / size.width, cs.surface)
            }
        }
    }
}

private fun openDownload(ctx: Context, e: DownloadEntity) {
    val uri: Uri = try {
        if (e.publicUri != null) Uri.parse(e.publicUri)
        else FileProvider.getUriForFile(ctx, "${ctx.packageName}.files", File(e.localPath))
    } catch (_: Exception) {
        Toast.makeText(ctx, "فایل پیدا نشد", Toast.LENGTH_SHORT).show()
        return
    }
    val intent = Intent(Intent.ACTION_VIEW)
        .setDataAndType(uri, mimeOf(e.fileName))
        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
    try {
        ctx.startActivity(intent)
    } catch (_: ActivityNotFoundException) {
        Toast.makeText(ctx, "برنامه‌ای برای باز کردن این فایل نیست", Toast.LENGTH_SHORT).show()
    }
}
