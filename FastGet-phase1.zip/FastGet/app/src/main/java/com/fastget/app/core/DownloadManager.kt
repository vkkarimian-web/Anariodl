package com.fastget.app.core

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.SystemClock
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.fastget.app.FastGetApp
import com.fastget.app.R
import com.fastget.app.data.DownloadDao
import com.fastget.app.data.DownloadEntity
import com.fastget.app.data.Kind
import com.fastget.app.data.Status
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CoroutineStart
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import java.io.File
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

/** Live (non-persisted) numbers for an active download. */
data class Live(val speed: Long = 0, val etaSec: Long = -1)

class DownloadManager(
    private val app: Context,
    val dao: DownloadDao,
    private val prefs: Prefs
) {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private val pumpLock = Mutex()

    private val client = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .followRedirects(true)
        .followSslRedirects(true)
        .retryOnConnectionFailure(true)
        .build()

    private class Running(val job: Job, val abort: () -> Unit)

    private val running = ConcurrentHashMap<Long, Running>()

    private companion object {
        const val VIDEO_SCALE = 10_000L
        const val VIDEO_REEXTRACT_MAX = 3
    }

    /** CDN / signed URL expired — re-run yt-dlp extraction (same page URL + format). */
    private fun isReextractable(msg: String?): Boolean {
        if (msg.isNullOrBlank()) return false
        val m = msg.lowercase()
        return listOf(
            "403", "forbidden", "404", "expired", "urlopen error",
            "unable to download video data", "fragment not found",
            "http error 403", "http error 404", "the downloaded file is empty",
        ).any { it in m }
    }

    private fun withinSchedule(e: DownloadEntity, now: Long = System.currentTimeMillis()): Boolean {
        if (e.scheduleStartMs > 0 && now < e.scheduleStartMs) return false
        if (e.scheduleStopMs > 0 && now >= e.scheduleStopMs) return false
        return true
    }

    private val _live = MutableStateFlow<Map<Long, Live>>(emptyMap())
    val live: StateFlow<Map<Long, Live>> = _live

    init {
        // A killed process leaves rows marked DOWNLOADING; show them as paused.
        scope.launch { dao.moveStatus(Status.DOWNLOADING, Status.PAUSED) }
    }

    // ---------- public API ----------

    fun enqueue(urls: List<String>, autoStart: Boolean) {
        scope.launch {
            for (u in urls) {
                val name = fileNameFromUrl(u)
                dao.insert(
                    DownloadEntity(
                        url = u,
                        fileName = name,
                        category = Category.of(name),
                        status = if (autoStart) Status.QUEUED else Status.PAUSED
                    )
                )
            }
            pump()
        }
    }

    fun enqueueVideo(url: String, title: String, thumb: String?, spec: String, private: Boolean) {
        scope.launch {
            val audio = spec.startsWith("a:")
            val ext = if (audio) spec.removePrefix("a:") else "mp4"
            val name = sanitizeFileName(title) + "." + ext
            dao.insert(
                DownloadEntity(
                    url = url,
                    fileName = name,
                    category = if (audio) Category.AUDIO else Category.VIDEO,
                    kind = Kind.VIDEO,
                    formatSpec = spec,
                    isPrivate = private,
                    thumbnail = thumb,
                    totalBytes = VIDEO_SCALE
                )
            )
            pump()
        }
    }

    fun pause(id: Long) {
        scope.launch {
            stopRunning(id)
            dao.setStatus(id, Status.PAUSED, null)
        }
    }

    fun resume(id: Long) {
        scope.launch {
            dao.setStatus(id, Status.QUEUED, null)
            pump()
        }
    }

    fun retry(id: Long) = resume(id)

    fun updateUrl(id: Long, url: String) {
        scope.launch { dao.setUrl(id, url.trim()) }
    }

    fun setPriority(id: Long, priority: Int) {
        scope.launch {
            dao.setPriority(id, priority)
            pump()
        }
    }

    fun setSchedule(id: Long, startMs: Long, stopMs: Long) {
        scope.launch { dao.setSchedule(id, startMs, stopMs) }
    }

    fun setCustomPath(id: Long, path: String) {
        scope.launch { dao.setCustomPath(id, path) }
    }

    fun pauseAll() {
        scope.launch {
            running.keys.toList().forEach { stopRunning(it) }
            dao.moveStatus(Status.DOWNLOADING, Status.PAUSED)
            dao.moveStatus(Status.QUEUED, Status.PAUSED)
        }
    }

    fun resumeAll() {
        scope.launch {
            dao.moveStatus(Status.PAUSED, Status.QUEUED)
            pump()
        }
    }

    /** Throws away partial data and downloads again from byte 0. */
    fun restart(id: Long) {
        scope.launch {
            stopRunning(id)
            val e = dao.get(id) ?: return@launch
            removeFiles(e)
            dao.update(
                e.copy(
                    localPath = "",
                    totalBytes = if (e.kind == Kind.VIDEO) VIDEO_SCALE else -1,
                    downloadedBytes = 0, segments = "",
                    status = Status.QUEUED, error = null, publicUri = null, finishedAt = 0
                )
            )
            pump()
        }
    }

    fun delete(id: Long, withFile: Boolean) {
        scope.launch {
            stopRunning(id)
            val e = dao.get(id)
            if (e != null && (withFile || e.status != Status.COMPLETED)) removeFiles(e)
            dao.delete(id)
            pump()
        }
    }

    // ---------- scheduling ----------

    fun pump() {
        scope.launch {
            pumpLock.withLock {
                if (prefs.wifiOnly && !isOnWifi()) return@withLock
                val slots = prefs.maxParallel - running.size
                if (slots <= 0) return@withLock
                dao.byStatus(Status.QUEUED)
                    .filter { !running.containsKey(it.id) }
                    .take(slots)
                    .forEach { start(it) }
            }
        }
    }

    private suspend fun start(e: DownloadEntity) {
        if (!prefs.isGlobalScheduleActive()) {
            return
        }
        if (!withinSchedule(e)) {
            // Waiting for per-item schedule window — leave QUEUED; pump will retry later.
            return
        }
        dao.setStatus(e.id, Status.DOWNLOADING, null)
        val job: Job
        val abort: () -> Unit
        if (e.kind == Kind.VIDEO) {
            val pid = "dl-${e.id}"
            job = scope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) { runVideo(e.id, pid) }
            abort = { VideoEngine.cancel(pid) }
        } else {
            val dl = SegmentedDownloader(client)
            job = scope.launch(Dispatchers.IO, start = CoroutineStart.LAZY) { runDownload(e.id, dl) }
            abort = { dl.abort() }
        }
        running[e.id] = Running(job, abort)
        DownloadService.start(app)
        job.start()
    }

    private suspend fun stopRunning(id: Long) {
        val r = running[id] ?: return
        r.job.cancel()
        r.abort()
        r.job.join()
    }

    // ---------- the actual work ----------

    private suspend fun runDownload(id: Long, dl: SegmentedDownloader) {
        var segs: List<Seg> = emptyList()
        try {
            val e0 = dao.get(id) ?: return
            val probe = dl.probe(e0.url)
            val total = probe.total
            val canRange = probe.acceptRanges && total > 0

            val dir = downloadsDir()
            var entity = e0

            // Can we resume? Same size, same validators, partial file still there.
            val old = Segments.decode(e0.segments)
            val partOld = if (e0.localPath.isNotEmpty()) File(e0.localPath + ".part") else null
            val sameFile = old.isNotEmpty() && canRange &&
                e0.totalBytes == total &&
                (e0.etag == null || probe.etag == null || e0.etag == probe.etag) &&
                (e0.lastModified == null || probe.lastModified == null ||
                    e0.lastModified == probe.lastModified) &&
                partOld?.exists() == true

            if (sameFile) {
                segs = old
            } else {
                if (partOld != null) partOld.delete()
                val name = sanitizeFileName(probe.fileName ?: e0.fileName)
                val target = uniqueFile(dir, name)
                segs = when {
                    canRange -> Segments.split(total, prefs.threads)
                    else -> listOf(Seg(0, if (total > 0) total - 1 else -1))
                }
                entity = e0.copy(
                    fileName = target.name,
                    category = Category.of(target.name),
                    localPath = target.absolutePath
                )
            }

            entity = entity.copy(
                totalBytes = total,
                acceptRanges = canRange,
                etag = probe.etag,
                lastModified = probe.lastModified,
                segments = Segments.encode(segs),
                downloadedBytes = segs.sumOf { it.done.get() },
                error = null
            )
            // Keep the status column out of this write: the user may have paused meanwhile.
            val current = dao.get(id) ?: return
            dao.update(entity.copy(status = current.status))

            val part = File(entity.localPath + ".part")
            val limiter = SpeedLimiter(prefs.speedLimitKb * 1024)

            suspend fun downloadProgress(downloaded: Long, speed: Long, enc: String) {
                dao.setProgress(id, downloaded, enc)
                val eta = if (speed > 0 && total > 0) (total - downloaded) / speed else -1L
                _live.update { it + (id to Live(speed, eta)) }
            }

            try {
                dl.download(entity.url, part, total, canRange, segs, limiter) { downloaded, speed, enc ->
                    downloadProgress(downloaded, speed, enc)
                }
            } catch (rangeError: RangeNotSupportedException) {
                // Some CDNs advertise ranges during probing but ignore them on actual requests.
                // Restart safely as a single stream instead of leaving a permanently failed item.
                part.delete()
                segs = listOf(Seg(0, if (total > 0) total - 1 else -1))
                val latest = dao.get(id) ?: throw rangeError
                entity = latest.copy(
                    acceptRanges = false,
                    segments = Segments.encode(segs),
                    downloadedBytes = 0,
                    error = null
                )
                dao.update(entity)
                dl.download(entity.url, part, total, false, segs, limiter) { downloaded, speed, enc ->
                    downloadProgress(downloaded, speed, enc)
                }
            }

            val sum = segs.sumOf { it.done.get() }
            if (total > 0 && sum != total) throw IOException("حجم فایل با مقدار انتظار برابر نیست")

            val finalFile = File(entity.localPath)
            if (!part.renameTo(finalFile)) throw IOException("تغییر نام فایل ناموفق بود")

            var pub: String? = null
            if (prefs.publishToDownloads) {
                pub = publishToDownloads(app, finalFile, entity.fileName)
            }

            val cur = dao.get(id) ?: return
            dao.update(
                cur.copy(
                    status = Status.COMPLETED,
                    totalBytes = if (total > 0) total else sum,
                    downloadedBytes = sum,
                    segments = "",
                    publicUri = pub,
                    error = null,
                    finishedAt = System.currentTimeMillis()
                )
            )
            notifyDone(entity.fileName)
        } catch (ce: CancellationException) {
            persistProgress(id, segs)
            throw ce
        } catch (t: Throwable) {
            persistProgress(id, segs)
            dao.setStatus(id, Status.FAILED, t.message ?: "خطای ناشناخته")
        } finally {
            running.remove(id)
            _live.update { it - id }
            pump()
        }
    }

    /**
     * Video/audio from YouTube and other sites via yt-dlp. Progress is stored as 0..9999
     * (percent x 100) on a virtual 10000 scale, because the real size is not known up front.
     */
    private suspend fun runVideo(id: Long, pid: String) {
        val work = File(app.filesDir, "yt/$id")
        try {
            var e0 = dao.get(id) ?: return
            work.mkdirs()
            var lastWrite = 0L
            var attempt = 0
            while (true) {
                e0 = dao.get(id) ?: return
                if (!withinSchedule(e0)) {
                    dao.setStatus(id, Status.PAUSED, null)
                    return
                }
                try {
                    VideoEngine.download(e0.url, e0.formatSpec, work, pid) { pct, eta, speed ->
                        _live.update { it + (id to Live(speed, eta)) }
                        val now = SystemClock.elapsedRealtime()
                        if (now - lastWrite > 500) {
                            lastWrite = now
                            val v = (pct * 100).toLong().coerceIn(0, VIDEO_SCALE - 1)
                            scope.launch {
                                dao.setProgressFull(id, v, VIDEO_SCALE, "", speed)
                            }
                        }
                    }
                    break // success
                } catch (ce: CancellationException) {
                    throw ce
                } catch (t: Throwable) {
                    if (!currentCoroutineContext().isActive) throw CancellationException("cancelled")
                    attempt++
                    val msg = t.message
                    if (attempt <= VIDEO_REEXTRACT_MAX && isReextractable(msg)) {
                        // Keep partials in work/; yt-dlp --continue resumes after re-extract.
                        _live.update { it + (id to Live(0, -1)) }
                        continue
                    }
                    throw t
                }
            }

            val out = VideoEngine.pickOutput(work) ?: throw IOException("فایل خروجی پیدا نشد")
            val name = sanitizeFileName(out.name)
            var pub: String? = null
            val target: File
            if (e0.isPrivate) {
                // Private: stays inside the app sandbox, never published to the gallery/Downloads.
                target = uniqueFile(File(app.filesDir, "vault").apply { mkdirs() }, name)
                moveFile(out, target)
            } else {
                target = uniqueFile(downloadsDir(), name)
                moveFile(out, target)
                if (prefs.publishToDownloads) pub = publishToDownloads(app, target, target.name)
            }
            val size = if (target.exists()) target.length() else (pub?.let { 1L } ?: 0L)

            val cur = dao.get(id) ?: return
            dao.update(
                cur.copy(
                    status = Status.COMPLETED,
                    fileName = target.name,
                    category = Category.of(target.name),
                    localPath = target.absolutePath,
                    totalBytes = size,
                    downloadedBytes = size,
                    publicUri = pub,
                    error = null,
                    finishedAt = System.currentTimeMillis()
                )
            )
            work.deleteRecursively()
            notifyDone(target.name, e0.isPrivate)
        } catch (ce: CancellationException) {
            throw ce
        } catch (t: Throwable) {
            // A killed yt-dlp process surfaces as an exception; that is a pause, not a failure.
            if (!currentCoroutineContext().isActive) throw CancellationException("cancelled")
            dao.setStatus(id, Status.FAILED, VideoEngine.friendlyError(t))
        } finally {
            running.remove(id)
            _live.update { it - id }
            pump()
        }
    }

    private suspend fun persistProgress(id: Long, segs: List<Seg>) {
        if (segs.isEmpty()) return
        withContext(NonCancellable) {
            dao.setProgress(id, segs.sumOf { it.done.get() }, Segments.encode(segs))
        }
    }

    // ---------- helpers ----------

    private fun downloadsDir(): File {
        val d = app.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)
            ?: File(app.filesDir, "downloads")
        d.mkdirs()
        return d
    }

    private fun removeFiles(e: DownloadEntity) {
        File(app.filesDir, "yt/${e.id}").deleteRecursively()
        if (e.localPath.isNotEmpty()) {
            File(e.localPath).delete()
            File(e.localPath + ".part").delete()
        }
        e.publicUri?.let {
            runCatching { app.contentResolver.delete(Uri.parse(it), null, null) }
        }
    }

    private fun isOnWifi(): Boolean {
        val cm = app.getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) ||
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
    }

    private fun notifyDone(name: String, private: Boolean = false) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ActivityCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) return
        val n = NotificationCompat.Builder(app, FastGetApp.CHANNEL_DONE)
            .setSmallIcon(R.drawable.ic_stat_download)
            .setContentTitle("دانلود کامل شد")
            .setContentText(if (private) "یک دانلود خصوصی" else name)
            .setVisibility(if (private) NotificationCompat.VISIBILITY_SECRET else NotificationCompat.VISIBILITY_PRIVATE)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(app).notify(name.hashCode(), n)
    }
}
