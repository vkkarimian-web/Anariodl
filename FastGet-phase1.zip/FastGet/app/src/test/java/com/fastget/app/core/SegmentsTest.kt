package com.fastget.app.core

import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SegmentsTest {
    @Test
    fun splitCreatesContiguousNonOverlappingRanges() {
        val total = 10_000_000L
        val segments = Segments.split(total, 4)

        assertEquals(4, segments.size)
        assertEquals(0L, segments.first().start)
        assertEquals(total - 1, segments.last().end)
        assertEquals(total, segments.sumOf { it.length })
        segments.zipWithNext().forEach { (left, right) ->
            assertEquals(left.end + 1, right.start)
        }
    }

    @Test
    fun splitKeepsSmallFilesOnOneConnection() {
        val segments = Segments.split(512_000L, 16)
        assertEquals(1, segments.size)
        assertEquals(0L, segments.single().start)
        assertEquals(511_999L, segments.single().end)
    }

    @Test
    fun encodeDecodePreservesProgress() {
        val original = listOf(Seg(0, 99, 40), Seg(100, 199, 75))
        val decoded = Segments.decode(Segments.encode(original))

        assertEquals(2, decoded.size)
        assertEquals(40L, decoded[0].done.get())
        assertEquals(75L, decoded[1].done.get())
        assertTrue(decoded.all { it.done.get() <= it.length })
    }
}
